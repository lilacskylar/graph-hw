package graphlib;

public interface NodeVisitor
{
    public void visit(Node node);
}
