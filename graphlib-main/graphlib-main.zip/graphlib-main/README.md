# Simple implementation of a Graph in Java

* Supports directed, undirected, weighted and unweighted graphs
* Supports BFS and DFS traversal algorithms
* Not particularly optimized for performance, but should be good enough for small graphs
* Feel free to use this code in your projects